<?php

class functions
{

// הוספת מרץ חדש
    function addLecturer($name, $mailbox, $phone)
    {
        global $conn;
        $name = mysqli_real_escape_string($conn, $name);
        $mailbox = intval($mailbox);
        $phone = mysqli_real_escape_string($conn, $phone);
        $sql = "INSERT INTO `data` (lecturer_name, mailbox_number, phone_number) VALUES ('$name', $mailbox, '$phone')";
        return $conn->query($sql);
    }

// עדכון פרטי מרץ
    function updateLecturer($id, $name, $mailbox, $phone)
    {
        global $conn;
        $id = intval($id);
        $name = mysqli_real_escape_string($conn, $name);
        $mailbox = intval($mailbox);
        $phone = mysqli_real_escape_string($conn, $phone);
        $sql = "UPDATE `data` SET lecturer_name='$name', mailbox_number=$mailbox, phone_number='$phone' WHERE id=$id";
        return $conn->query($sql);
    }

// מחיקת מרץ
    function deleteLecturer($id)
    {
        global $conn;
        $id = intval($id);
        $sql = "DELETE FROM `data` WHERE id=$id";
        return $conn->query($sql);
    }

// קבלת רשימת המרצים
    function getLecturers()
    {
        global $conn;
        $sql = "SELECT * FROM `data`";
        $result = $conn->query($sql);
        $lecturers = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $lecturers[] = $row;
            }
        }
        return $lecturers;
    }


}