<?php
$db_host="localhost";
$db_user="root";
$db_pass="";
$db_schema="matala";
